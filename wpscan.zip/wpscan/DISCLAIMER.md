WPScan is not responsible for misuse or for any damage that you may cause!
You agree that you use this software at your own risk.
